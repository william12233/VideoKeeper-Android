package org.gradle.wrapper;

// Minimal, auditable Gradle distribution bootstrapper supplied because the standard
// wrapper binary is not available in this offline creation environment.
// This only downloads the official Gradle 8.13 binary from services.gradle.org,
// verifies the official SHA-256, unzips it, and executes bin/gradle.
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import java.security.*;
import java.time.Duration;
import java.util.*;
import java.util.zip.*;

public final class GradleWrapperMain {
    private static final String EXPECTED = "20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78";
    public static void main(String[] args) throws Exception {
        Path project = Paths.get(System.getProperty("user.dir"));
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(project.resolve("gradle/wrapper/gradle-wrapper.properties"))) { p.load(in); }
        String url = p.getProperty("distributionUrl");
        if (!"https://services.gradle.org/distributions/gradle-8.13-bin.zip".equals(url)) {
            throw new SecurityException("Unexpected Gradle distribution URL: " + url);
        }
        Path root = Paths.get(System.getProperty("user.home"), ".gradle", "wrapper", "dists", "videokeeper_8_13");
        Path home = root.resolve("gradle-8.13");
        Path zip = root.resolve("gradle-8.13-bin.zip");
        Path marker = root.resolve(".sha256-verified");
        Files.createDirectories(root);
        if (!Files.isRegularFile(marker) || !Files.isRegularFile(home.resolve("bin/gradle"))) {
            if (!Files.isRegularFile(zip) || !sha(zip).equalsIgnoreCase(EXPECTED)) {
                System.out.println("Downloading Gradle 8.13 from the official distribution host...");
                HttpClient client = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.ALWAYS)
                    .connectTimeout(Duration.ofSeconds(40)).build();
                HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofMinutes(12)).GET().build();
                HttpResponse<Path> response = client.send(request, HttpResponse.BodyHandlers.ofFile(zip));
                if (response.statusCode() != 200) throw new IOException("Gradle download HTTP " + response.statusCode());
            }
            if (!sha(zip).equalsIgnoreCase(EXPECTED)) {
                Files.deleteIfExists(zip);
                throw new SecurityException("Gradle 8.13 distribution checksum mismatch");
            }
            System.out.println("Verified Gradle distribution SHA-256. Extracting...");
            try (ZipFile archive = new ZipFile(zip.toFile())) {
                Enumeration<? extends ZipEntry> entries = archive.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry e = entries.nextElement();
                    Path dest = root.resolve(e.getName()).normalize();
                    if (!dest.startsWith(root)) throw new SecurityException("Archive traversal rejected");
                    if (e.isDirectory()) { Files.createDirectories(dest); continue; }
                    Files.createDirectories(dest.getParent());
                    try (InputStream in = archive.getInputStream(e)) { Files.copy(in, dest, StandardCopyOption.REPLACE_EXISTING); }
                }
            }
            Files.writeString(marker, EXPECTED);
        }
        boolean windows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        Path binary = home.resolve("bin").resolve(windows ? "gradle.bat" : "gradle");
        if (!windows) binary.toFile().setExecutable(true);
        List<String> command = new ArrayList<>();
        if (windows) { command.add("cmd.exe"); command.add("/c"); }
        command.add(binary.toAbsolutePath().toString());
        Collections.addAll(command, args);
        Process process = new ProcessBuilder(command).directory(project.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }
    private static String sha(Path path) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(path)) {
            byte[] buf = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) if (n > 0) md.update(buf, 0, n);
        }
        StringBuilder result = new StringBuilder();
        for (byte b : md.digest()) result.append(String.format("%02x", b & 255));
        return result.toString();
    }
}
